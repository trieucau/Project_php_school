-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2024 at 11:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tmdt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `congty`
--

CREATE TABLE `congty` (
  `idcty` int(10) UNSIGNED NOT NULL,
  `tencty` varchar(255) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  `dienthoai` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `congty`
--

INSERT INTO `congty` (`idcty`, `tencty`, `diachi`, `dienthoai`, `fax`) VALUES
(1, 'Apple', 'Mỹ', '0373 234 244', '1111'),
(2, 'Xiaomi', 'Trung Quốc', '0373 234 244', '2222'),
(3, 'Samsung', 'Hàn Quốc', '0373 234 244', '2222');

-- --------------------------------------------------------

--
-- Table structure for table `dathang`
--

CREATE TABLE `dathang` (
  `iddh` int(10) UNSIGNED NOT NULL,
  `idkh` int(11) NOT NULL,
  `id_nhanvien` int(11) NOT NULL,
  `ngaydathang` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `trangthai` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dathang`
--

INSERT INTO `dathang` (`iddh`, `idkh`, `id_nhanvien`, `ngaydathang`, `trangthai`) VALUES
(61, 1, 0, '2024-11-15 20:56:16', 1),
(62, 1, 0, '2024-11-15 20:56:16', 1),
(63, 1, 0, '2024-11-15 20:56:16', 1),
(64, 1, 0, '2024-11-15 21:00:33', 1),
(65, 1, 0, '2024-11-15 21:05:01', 1),
(66, 1, 0, '2024-11-15 21:08:04', 1),
(67, 1, 0, '2024-11-15 21:11:29', 1),
(68, 1, 0, '2024-11-15 21:13:23', 1),
(69, 1, 0, '2024-11-15 21:15:07', 1),
(70, 1, 0, '2024-11-15 21:17:36', 1),
(71, 1, 0, '2024-11-15 21:21:33', 1),
(72, 1, 0, '2024-11-15 21:22:16', 1),
(73, 1, 0, '2024-11-15 21:26:40', 1),
(74, 1, 0, '2024-11-15 21:51:41', 1),
(75, 1, 0, '2024-11-15 21:51:41', 1),
(76, 1, 0, '2024-11-15 22:01:48', 1),
(77, 1, 0, '2024-11-16 03:28:28', 1),
(78, 1, 0, '2024-11-16 03:28:28', 1),
(79, 1, 0, '2024-11-16 03:28:28', 1),
(80, 1, 0, '2024-11-16 03:31:02', 1),
(81, 1, 0, '2024-11-17 05:14:01', 1),
(82, 1, 0, '2024-11-17 05:14:01', 1),
(83, 1, 0, '2024-11-17 05:14:01', 1),
(84, 1, 0, '2024-11-17 05:14:01', 1),
(85, 1, 0, '2024-11-17 05:14:01', 1),
(86, 1, 0, '2024-11-16 23:19:25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dathang_chitiet`
--

CREATE TABLE `dathang_chitiet` (
  `iddh` int(11) NOT NULL,
  `idsp` int(11) NOT NULL,
  `soluong` int(11) NOT NULL,
  `dongia` int(11) NOT NULL,
  `giamgia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dathang_chitiet`
--

INSERT INTO `dathang_chitiet` (`iddh`, `idsp`, `soluong`, `dongia`, `giamgia`) VALUES
(61, 9, 1, 770, 11),
(62, 12, 10, 793, 11),
(64, 11, 3, 793, 15),
(65, 10, 3, 770, 15),
(66, 5, 1, 993, 9),
(67, 11, 1, 793, 15),
(68, 9, 1, 770, 11),
(69, 9, 1, 770, 11),
(70, 5, 1, 993, 9),
(71, 11, 1, 793, 15),
(72, 15, 1, 790, 11),
(73, 6, 1, 779, 9),
(75, 15, 2, 790, 11),
(76, 4, 1, 993, 9),
(78, 11, 1, 793, 15),
(79, 9, 1, 770, 11),
(80, 11, 1, 793, 15),
(84, 32, 3, 2000, 12),
(85, 32, 4, 2000, 12);

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `idkh` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `hodem` varchar(255) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  `diachinhanhang` varchar(255) NOT NULL,
  `dienthoai` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`idkh`, `email`, `password`, `hodem`, `ten`, `diachi`, `diachinhanhang`, `dienthoai`) VALUES
(1, 'trieu@gmail.com', '1232we', 'phan thanh', 'trieu', 'binh dinh', '202/an phu dong/12/hcm', '0898 252 724');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `idsp` int(10) UNSIGNED NOT NULL,
  `tensp` varchar(255) NOT NULL,
  `gia` int(11) NOT NULL,
  `mota` varchar(255) NOT NULL,
  `hinh` varchar(255) NOT NULL,
  `giamgia` int(11) NOT NULL,
  `idcty` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`idsp`, `tensp`, `gia`, `mota`, `hinh`, `giamgia`, `idcty`) VALUES
(32, 'iphone6', 2000, 'đa chức năng mới', 'iphone2.jpg', 12, 1),
(37, 'samsung1', 777, 'đa chức năng mới', 'samsung1.jpg', 12, 3),
(38, 'iphone6', 1000, 'đa chức năng mới', 'iphone3.jpg', 12, 1);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `iduser` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `hodem` varchar(255) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `phanquyen` varchar(20) NOT NULL,
  `landang-nhapcuoi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`iduser`, `username`, `password`, `hodem`, `ten`, `phanquyen`, `landang-nhapcuoi`) VALUES
(1, 'usertmdt', '796ca4bb23366c9c89f66693b0ff8b72', 'phan thanh', 'trieu', 'read', '2024-11-15 05:15:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `congty`
--
ALTER TABLE `congty`
  ADD PRIMARY KEY (`idcty`);

--
-- Indexes for table `dathang`
--
ALTER TABLE `dathang`
  ADD PRIMARY KEY (`iddh`);

--
-- Indexes for table `dathang_chitiet`
--
ALTER TABLE `dathang_chitiet`
  ADD PRIMARY KEY (`iddh`,`idsp`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`idkh`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`idsp`),
  ADD KEY `test3` (`idcty`);

--
-- Indexes for table `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`iduser`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `username_2` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `congty`
--
ALTER TABLE `congty`
  MODIFY `idcty` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dathang`
--
ALTER TABLE `dathang`
  MODIFY `iddh` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `khachhang`
--
ALTER TABLE `khachhang`
  MODIFY `idkh` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `idsp` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `taikhoan`
--
ALTER TABLE `taikhoan`
  MODIFY `iduser` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `test3` FOREIGN KEY (`idcty`) REFERENCES `congty` (`idcty`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
